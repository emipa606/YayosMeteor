﻿using System;
using UnityEngine;
using Verse;

namespace MeteorIncident
{
	// Token: 0x02000005 RID: 5
	public static class Settings_SliderExtenter
	{
		// Token: 0x0600000F RID: 15 RVA: 0x000024CA File Offset: 0x000006CA
		public static void GapGapLine(this Listing_Standard ls, float gapHeight = 12f)
		{
			ls.Gap(gapHeight);
			ls.GapLine(gapHeight);
			ls.Gap(gapHeight);
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002588 File Offset: 0x00000788
		public static void MeteorIntervalSlider(this Listing_Standard ls, string label, ref int val, string tooltip = null)
		{
			Rect rect = ls.GetRect(30f);
			Rect rect2 = GenUI.LeftHalf(rect);
			Rect rect3 = GenUI.RightHalf(rect);
			bool flag = tooltip != null;
			if (flag)
			{
				TooltipHandler.TipRegion(rect3, new TipSignal(tooltip));
			}
			Widgets.Label(rect2, label);
			val = Settings_Sliders.MeteorEventFrequencyHorizontalSlider(rect3, val);
		}

		// Token: 0x04000007 RID: 7
		private const float BaseLineHeight = 30f;
	}
}
