﻿using System;
using System.Collections.Generic;
using RimWorld;
using Verse;

namespace MeteorIncident
{
	// Token: 0x02000007 RID: 7
	public class Meteor_Object
	{

		int MeteorSizeIndex = 6;

		// Token: 0x06000016 RID: 22 RVA: 0x00002624 File Offset: 0x00000824
		public void generateMeteor(IntVec3 targetCell, Map targetMap, int tryForStandardRock, bool bl_big = true)
		{

			int tries = 0;
			List<Thing> thingList = new List<Thing>();

            /*
			while (thingList[0].def.building.isResourceRock)
			{
				bool flag = tries == tryForStandardRock;
				if (flag)
				{
					break;
				}
				thingList = ThingSetMakerDefOf.Meteorite.root.Generate();
               
				tries++;
			}
            */
            if (bl_big)
            {
                thingList.Add(ThingMaker.MakeThing(ThingDefOf.ChunkSlagSteel));
            }
            else
            {
                switch (Rand.Range(0, 7))
                {
                    default:
                        thingList.Add(ThingMaker.MakeThing(ThingDefOf.StandingLamp));
                        break;
                    case 1:
                        thingList.Add(ThingMaker.MakeThing(ThingDefOf.SolarGenerator));
                        break;
                    case 2:
                        thingList.Add(ThingMaker.MakeThing(ThingDefOf.WindTurbine));
                        break;
                    case 3:
                        thingList.Add(ThingMaker.MakeThing(ThingDefOf.Heater));
                        break;
                    case 4:
                        thingList.Add(ThingMaker.MakeThing(ThingDefOf.Cooler));
                        break;
                    case 5:
                        thingList.Add(ThingMaker.MakeThing(ThingDefOf.Battery));
                        break;


                }
                
            }
            
            
            

            int minSizeIndex = Math.Min(0, MeteorSizeIndex - 3);
			int maxSizeIndex = Math.Min(Meteor_Object.MeteorSize.Length - 1, MeteorSizeIndex + 2);
			int meteorSize = new Random().Next(Meteor_Object.MeteorSize[minSizeIndex], Meteor_Object.MeteorSize[maxSizeIndex]);
			ThingDef smallMet = ThingDefOf.MeteoriteIncoming;
            float speed = 0.5f;
			smallMet.skyfaller.speed = (float)speed;

            float dmg = 0.9f;
            float explosionSize = 36f;

            

            switch (Find.FactionManager.OfPlayer.def.techLevel)
            {
                default:
                    explosionSize = 56f;
                    break;
                case TechLevel.Animal:
                    explosionSize = 36f;
                    break;
                case TechLevel.Neolithic:
                    explosionSize = 36f;
                    break;
                case TechLevel.Medieval:
                    explosionSize = 46f;
                    break;

            }

            if (targetMap.TileInfo.hilliness.ToString() == "Impassable")
            {
                explosionSize *= 0.3f;
                if (Rand.Chance(0.4f))
                {
                    thingList = new List<Thing>();
                    thingList.Add(ThingMaker.MakeThing(ThingDefOf.StandingLamp));
                }
            }


            if (!bl_big)
            {
                explosionSize = 2;
                dmg = 0f;
            }

            smallMet.skyfaller.explosionDamageFactor = dmg;
            smallMet.skyfaller.explosionRadius = explosionSize;
			smallMet.skyfaller.shrapnelDistanceFactor = explosionSize;
			smallMet.skyfaller.ticksToImpactRange = new IntRange(15, 125);
			SkyfallerMaker.SpawnSkyfaller(smallMet, thingList, targetCell, targetMap);

        }



        public void generateMeteor2(IntVec3 targetCell, Map targetMap, int tryForStandardRock, bool bl_big = true)
        {

            int tries = 0;
            List<Thing> thingList = new List<Thing>();

            /*
			while (thingList[0].def.building.isResourceRock)
			{
				bool flag = tries == tryForStandardRock;
				if (flag)
				{
					break;
				}
				thingList = ThingSetMakerDefOf.Meteorite.root.Generate();
               
				tries++;
			}
            */
            if (Rand.Chance(0.5f))
            {
                thingList.Add(ThingMaker.MakeThing(ThingDefOf.ChunkSlagSteel));
            }
            else
            {
                thingList.Add(ThingMaker.MakeThing(ThingDefOf.MineableSteel));
            }
            




            int minSizeIndex = Math.Min(0, MeteorSizeIndex - 3);
            int maxSizeIndex = Math.Min(Meteor_Object.MeteorSize.Length - 1, MeteorSizeIndex + 2);
            int meteorSize = new Random().Next(Meteor_Object.MeteorSize[minSizeIndex], Meteor_Object.MeteorSize[maxSizeIndex]);
            ThingDef smallMet = ThingDefOf.ShipChunkIncoming;
            float speed = 0.5f;
            smallMet.skyfaller.speed = (float)speed;

            smallMet.skyfaller.explosionDamageFactor = 0.01f;
            float explosionSize = 2;
            smallMet.skyfaller.explosionRadius = explosionSize;
            smallMet.skyfaller.shrapnelDistanceFactor = explosionSize;
            smallMet.skyfaller.ticksToImpactRange = new IntRange(15, 125);
            SkyfallerMaker.SpawnSkyfaller(smallMet, thingList, targetCell, targetMap);

        }




        // Token: 0x04000009 RID: 9
        private static int[] MeteorSize = new int[]
		{
			1,
			2,
			3,
			4,
			6,
			8,
			10,
			12,
			16,
			18,
			20,
			24,
			28,
			32,
			42
		};
	}
}
