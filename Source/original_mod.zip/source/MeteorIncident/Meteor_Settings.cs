﻿using System;
using UnityEngine;
using Verse;

namespace MeteorIncident
{
	// Token: 0x02000008 RID: 8
	public class Meteor_Settings : ModSettings
	{
		// Token: 0x0600001A RID: 26 RVA: 0x00002784 File Offset: 0x00000984
		public void DoWindowContents(Rect rect)
		{
			Listing_Standard ls = new Listing_Standard();
			ls.Begin(rect);
			ls.Gap(10f);
			ls.MeteorIntervalSlider("The time from the warning to the Meteo drop (default : 7.5)", ref Meteor_Settings.MeteorDelay, "It is not an absolute value. This value is determined by the storyteller difficulty.");
			ls.Gap(10f);
			ls.End();
		}

		public static int MeteorDelay = 8;

	}
}
