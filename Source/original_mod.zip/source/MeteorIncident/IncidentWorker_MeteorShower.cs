﻿using System;
using RimWorld;
using UnityEngine;
using Verse;
/*
namespace MeteorIncident
{
	public class IncidentWorker_MeteorShower : IncidentWorker
	{
		protected override bool CanFireNowSub(IncidentParms parms)
		{
            return base.CanFireNowSub(parms);
        }

		protected override bool TryExecuteWorker(IncidentParms parms)
		{
			Find.CurrentMap.weatherManager.TransitionTo(WeatherDef.Named("RedThunderstorm"));

			Find.LetterStack.ReceiveLetter(
				"RedThunderstorm_letterTitle".Translate(), 
				"RedThunderstorm_letterDesc".Translate(), 
				LetterDefOf.NeutralEvent
				);
            return true;
		}

		private bool TryFindCell(out IntVec3 cell, Map map)
		{
			int maxMineables = ThingSetMaker_Meteorite.MineablesCountRange.max;
            return CellFinderLoose.TryFindSkyfallerCell(ThingDefOf.MeteoriteIncoming, map, out cell, 10, default(IntVec3), -1, false, true, true, true, false, false, null);
           
		}

		private Meteor_Object meteor = new Meteor_Object();
	}
}
*/