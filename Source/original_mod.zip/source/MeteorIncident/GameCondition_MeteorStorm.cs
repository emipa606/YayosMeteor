﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace MeteorIncident
{
	public class GameCondition_MeteorStorm : GameCondition
	{
        bool flag2 = false;
        IntVec3 targetPoint = IntVec3.Zero;
        IntVec3 targetPoint2 = IntVec3.Zero;
        int strikeCount = 1;

        public override void ExposeData()
		{
			base.ExposeData();
			Scribe_Values.Look<int>(ref GameCondition_MeteorStorm.nextMeteorTicks, "nextMeteorTicks", nextMeteorTicksReset, false);
		}

		public override void GameConditionTick()
		{

            bool flag = Find.TickManager.TicksGame <= GameCondition_MeteorStorm.nextMeteorTicks;
            if (!flag)
            {
                
                if (!flag2) {
                    flag2 = this.TryFindCell(out targetPoint, base.SingleMap);
                    strikeCount = Rand.Range(3, 5);
                }

				if (flag2 && strikeCount > 0)
				{
                    strikeCount--;
                    if(strikeCount == 0)
                    {
                        this.meteor.generateMeteor(targetPoint, base.SingleMap, 3, false);
                    }
                    else
                    {
                        this.meteor.generateMeteor(targetPoint, base.SingleMap, 3);
                    }
                    
                    GameCondition_MeteorStorm.nextMeteorTicks = Find.TickManager.TicksGame + GameCondition_MeteorStorm.TicksBetweenStrikes.RandomInRange;
				}
			}


            if (flag2 && Find.TickManager.TicksGame % 40 == 0 && strikeCount > 0)
            {
                bool flagR = false;
                flagR = CellFinderLoose.TryFindSkyfallerCell(ThingDefOf.ShipChunkIncoming, base.SingleMap, out targetPoint2, 10, targetPoint, 20, false, true, true, true, false, false, null);
                if (flagR)
                {
                    this.meteor.generateMeteor2(targetPoint2, base.SingleMap, 3);
                }
                
            }



        }

		public override float SkyTargetLerpFactor(Map map)
		{
            return GameConditionUtility.LerpInOutValue(this, 5000f, 0.5f);
        }

		public override SkyTarget? SkyTarget(Map map)
		{
			return new SkyTarget?(new SkyTarget(0.85f, this.MeteorStormColors, 1f, 1f));
		}


		private bool TryFindCell(out IntVec3 cell, Map map)
		{
			int maxMineables = ThingSetMaker_Meteorite.MineablesCountRange.max;
            bool flag = false;
            
            if (Rand.Chance(0.35f))
            {
                // colonist target

                List<Pawn> ar_pawn = new List<Pawn>();
                List<Pawn> ar_pawn_all = map.mapPawns.FreeColonists.ToList<Pawn>();

                if (Rand.Chance(0.7f))
                {
                    // out door target
                    foreach (Pawn p in ar_pawn_all)
                    {
                        Room tmp_room = p.GetRoom(RegionType.Set_Passable);
                        if (tmp_room != null && !tmp_room.PsychologicallyOutdoors)
                        {
                            // indoor pawn
                            
                        }
                        else
                        {
                            // outdoor pawn
                            ar_pawn.Add(p);
                        }
                        
                    }
                    
                    if (ar_pawn.Count == 0)
                    {
                        flag = CellFinderLoose.TryFindSkyfallerCell(ThingDefOf.MeteoriteIncoming, map, out cell, 10, default(IntVec3), -1, false, true, true, true, false, false, null);
                        return flag;
                    }
                }
                else
                {
                    // any target
                    ar_pawn = ar_pawn_all;
                }



                IntVec3 tpoint = ar_pawn[Rand.Range(0, ar_pawn.Count)].Position;

                flag = CellFinderLoose.TryFindSkyfallerCell(ThingDefOf.MeteoriteIncoming, map, out cell, 10, tpoint, 30, false, true, true, true, false, false, null);

            }
            else
            {
                // random area target
                flag = CellFinderLoose.TryFindSkyfallerCell(ThingDefOf.MeteoriteIncoming, map, out cell, 10, default(IntVec3), -1, false, true, true, true, false, false, null);
            }

            return flag;

		}

		private static int minTicks = 300;

		private static readonly IntRange TicksBetweenStrikes = new IntRange(GameCondition_MeteorStorm.minTicks, GameCondition_MeteorStorm.minTicks);

        static public int nextMeteorTicksReset
        {
            get
            {
                //int diff = Find.Storyteller.difficulty.difficulty;
                int diff = 6;
                /*
                if(diff < 1)
                {
                    diff = 1;
                }
                if (diff > 7)
                {
                    diff = 7;
                }
                */
                return Mathf.RoundToInt(Meteor_Settings.MeteorDelay * 60);
            }
        }
        static public int nextMeteorTicks = 9999;
        
		private Meteor_Object meteor = new Meteor_Object();

		private SkyColorSet MeteorStormColors = new SkyColorSet(new ColorInt(251, 105, 45).ToColor, new Color(255f, 242f, 200f), new Color(0.8f, 0.5f, 0.5f), 0.85f);
	}
}
