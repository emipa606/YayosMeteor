﻿using System;
using UnityEngine;
using Verse;

namespace MeteorIncident
{
	// Token: 0x02000006 RID: 6
	public class Meteors_Mod : Mod
	{
		// Token: 0x06000013 RID: 19 RVA: 0x000025D7 File Offset: 0x000007D7
		public Meteors_Mod(ModContentPack modContentPack) : base(modContentPack)
		{
			this.settings = base.GetSettings<Meteor_Settings>();
		}

		// Token: 0x06000014 RID: 20 RVA: 0x000025F0 File Offset: 0x000007F0
		public override string SettingsCategory()
		{
			return "YAYO Meteor";
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002607 File Offset: 0x00000807
		public override void DoSettingsWindowContents(Rect rect)
		{
			this.settings.DoWindowContents(rect);
			this.settings.Write();
		}

		// Token: 0x04000008 RID: 8
		public Meteor_Settings settings;
	}
}
