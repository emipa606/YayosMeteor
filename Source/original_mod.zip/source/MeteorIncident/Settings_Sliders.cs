﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Verse;

namespace MeteorIncident
{
	// Token: 0x02000009 RID: 9
	public static class Settings_Sliders
	{
		// Token: 0x0600001C RID: 28 RVA: 0x00002890 File Offset: 0x00000A90
		public static int MeteorEventFrequencyHorizontalSlider(Rect rect, int freq)
		{
			int index = Settings_Sliders.IntervalValues.IndexOf(freq);
			bool flag = index < 0;
			if (flag)
			{
				index = Settings_Sliders.IntervalValues.IndexOf(750);
			}
			string str = ((float)Settings_Sliders.IntervalValues[index]/100f).ToString("F1") + " Sec";
			float num2 = (float)index / (float)(Settings_Sliders.IntervalValues.Count - 1);
			float num3 = Widgets.HorizontalSlider(rect, num2, 0f, 1f, true, str, null, null, -1f);
			bool flag2 = (double)num2 != (double)num3;
			if (flag2)
			{
				int index2 = (int)Math.Round((double)num3 * (double)(Settings_Sliders.IntervalValues.Count - 1));
				freq = Settings_Sliders.IntervalValues[index2];
			}
			return freq;
		}


		// Token: 0x04000012 RID: 18
		private static List<int> IntervalValues = new List<int>
		{
			1,
			100,
			200,
			300,
			400,
			500,
			600,
			750,
			900,
			1000,
			1100,
			1200,
			1300,
			1500,
			1700,
			1900
		};


	}
}
