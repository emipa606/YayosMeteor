﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace MeteorIncident
{
	public class IncidentWorker_MeteorStormCondition : IncidentWorker
	{
		protected override bool CanFireNowSub(IncidentParms parms)
		{
            return base.CanFireNowSub(parms);
		}

		protected override bool TryExecuteWorker(IncidentParms parms)
		{
			GameCondition_MeteorStorm.nextMeteorTicks = Find.TickManager.TicksGame + GameCondition_MeteorStorm.nextMeteorTicksReset;
			Map target = (Map)parms.target;
			int duration = Mathf.RoundToInt(this.def.durationDays.RandomInRange * 60000f);
			GameCondition_MeteorStorm conditionMeteor = (GameCondition_MeteorStorm)GameConditionMaker.MakeCondition(GameConditionDef.Named("MeteorStorm"), duration);
			target.gameConditionManager.RegisterCondition(conditionMeteor);
			LookTargets tmp_lookTargets = new LookTargets();
			List<Pawn> ar_pawn_all = target.mapPawns.FreeColonists.ToList<Pawn>();
			for (int i = 0; i < ar_pawn_all.Count; i++)
            {
                tmp_lookTargets.targets.Add(new TargetInfo(ar_pawn_all[i]));
            }


			Find.LetterStack.ReceiveLetter("Meteo_letterTitle".Translate(), 
				"Meteo_letterDesc".Translate(), 
				LetterDefOf.ThreatBig, 
				tmp_lookTargets
			);
            return true;
		}
	}
}
